const apiUrl = (process.env.EXPO_PUBLIC_API_URL ?? 'http://localhost:3333').replace(/\/+$/, '');

export const env = {
  apiUrl,
  apiBaseUrl: `${apiUrl}/api`,
} as const;
