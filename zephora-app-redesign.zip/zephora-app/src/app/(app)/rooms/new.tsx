export { default } from '@/features/rooms/screens/NewRoomScreen';
