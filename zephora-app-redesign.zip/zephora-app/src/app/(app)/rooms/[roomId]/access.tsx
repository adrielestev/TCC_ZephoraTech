export { default } from '@/features/rooms/screens/RoomAccessScreen';
