import { StyleSheet, View } from 'react-native';
import { AppText } from './AppText';
import { Icon } from './Icon';
import { colors, spacing } from './theme';

/** Logo do Zephora (ícone + nome). */
export function BrandMark({ size = 40, showName = true, inverted }: { size?: number; showName?: boolean; inverted?: boolean }) {
  return (
    <View style={styles.row} accessibilityLabel="Zephora">
      <View
        style={[
          styles.logo,
          { width: size, height: size, borderRadius: size * 0.3 },
          inverted && { backgroundColor: colors.surface },
        ]}
      >
        <Icon name="home" size={size * 0.55} color={inverted ? 'primary' : 'onPrimary'} />
      </View>
      {showName ? (
        <AppText variant="heading" color={inverted ? 'onPrimary' : 'primaryDark'}>
          Zephora
        </AppText>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  logo: { backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', borderCurve: 'continuous' },
});
