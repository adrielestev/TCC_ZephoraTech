import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { Colors, Heights, Spacing, FontSizes, FontWeights } from '../theme/constants';
import { useResponsive } from '../hooks/useResponsive';

const BIRD_PATH =
  'M43.4607 6.38191C44.6892 5.64706 46.3272 5.27964 47.5558 5.27964C48.337 5.27964 49.6687 5.3922 50.8318 6.01448C51.3991 6.318 52.0067 6.98067 52.3292 7.33246L52.3293 7.3325L52.3296 7.33288C52.3855 7.39383 52.4328 7.44542 52.4698 7.48417C52.6313 7.65305 52.6313 7.65305 52.898 7.70269C53.1648 7.75232 53.6984 7.85159 54.9269 8.21901C57.3839 8.95386 56.9744 9.44711 56.9744 9.44711C56.9744 9.44711 50.7259 11.4155 50.1742 12.5789C49.9859 12.9759 50.0247 13.9049 50.073 15.0607C50.1662 17.2917 50.073 19.8534 47.8318 23.0258C45.5906 26.1983 43.0184 27.7448 38.3939 29.0571C37.1108 29.4212 35.7937 29.7068 34.5198 29.9831C31.2028 30.7024 28.1793 31.3581 26.8139 33.1697C25.9656 34.2951 25.4981 34.9755 25.1019 35.5523C22.0714 39.864 19.5268 40.3699 14.3448 39.8173C14.3448 39.8173 17.1747 39.2422 18.846 37.8391C20.0206 36.8529 20.3767 36.0372 20.7595 35.1602C20.9213 34.7895 21.0879 34.4079 21.3232 33.9978C22.0726 32.6913 23.2569 31.5291 23.3811 31.4088C23.1589 31.6218 19.4755 35.0956 14.3768 36.344C9.11599 37.6321 2.42502 33.9978 2.42502 33.9978C2.42502 33.9978 11.239 34.5551 15.536 31.3985C17.1176 30.2367 17.8362 29.588 19.6351 27.9467C18.5315 30.4198 18.172 30.23 15.536 33.8113C20.9284 31.0043 25.4729 28.9237 26.4144 23.9899C25.1012 23.6624 24.2422 23.8735 22.633 25.3324C25.7214 22.5145 26.8065 21.2444 28.0895 20.245C30.1197 18.6635 33.63 16.5608 37.8102 15.1695C32.7166 10.4662 29.4501 10.0625 22.633 9.4882C38.1627 11.6352 26.4126 23.2725 19.0785 23.0258C11.7444 22.7792 9.30649 19.1755 9.30649 19.1755C14.5252 20.8108 18.9335 19.7808 21.5019 18.3483C24.0704 16.9159 24.7083 16.4361 24.7083 16.4361C22.4925 17.3076 19.6622 18.6006 14.5731 18.7212C9.48406 18.8417 0.713605 9.5998 0.713605 9.5998C0.713605 9.5998 9.38425 13.5333 15.6656 12.5194C21.947 11.5055 27.4273 13.1682 27.4273 13.1682C27.4273 13.1682 24.4216 11.8864 20.2684 11.1777C18.7709 10.9222 16.9378 10.8966 15.0629 10.8704H15.0629C11.7378 10.824 8.2814 10.7757 6.33331 9.43975C1.88427 6.38869 0 0 0 0C0 0 3.08099 2.26823 6.33331 4.12319C9.58563 5.97815 15.0629 7.31297 19.0785 7.31297C23.0941 7.31297 26.0647 7.53879 28.0895 8.95386C28.0895 8.95386 25.7214 6.38191 20.2684 5.27964C14.8154 4.17737 9.48406 3.19663 6.33331 1.23176C3.18256 -1.73311 0 0 0 0L43.4607 6.38191Z';

/**
 * `variant="badge"` (padrão) — ícone em um selo circular, usado em telas
 * internas/menores.
 * `variant="wordmark"` — logotipo horizontal "Zephora" + pássaro, igual à
 * referência de design da tela de login.
 */
export const ZephoraLogo = ({ size = Heights.logo, style, variant = 'badge' }) => {
  const { isSmallScreen } = useResponsive();

  if (variant === 'wordmark') {
    const wordmarkHeight = size * 0.6;
    return (
      <View style={[styles.wordmarkRow, style]}>
        <Text style={[styles.wordmarkText, { fontSize: isSmallScreen ? FontSizes.xxl : FontSizes.xxxl }]}>
          Zephora
        </Text>
        <Svg width={wordmarkHeight * 1.4} height={wordmarkHeight} viewBox="0 0 57 40" fill="none">
          <Path d={BIRD_PATH} fill={Colors.text.primary} />
        </Svg>
      </View>
    );
  }

  const svgSize = size * 0.7;
  return (
    <View style={[styles.container, { width: size, height: size, borderRadius: size / 2 }, style]}>
      <Svg width={svgSize} height={svgSize * 0.7} viewBox="0 0 57 40" fill="none">
        <Path d={BIRD_PATH} fill="white" />
      </Svg>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  wordmarkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  wordmarkText: {
    fontWeight: FontWeights.extrabold,
    color: Colors.text.primary,
    letterSpacing: -0.5,
    marginRight: Spacing.sm,
  },
});
